from django.contrib import admin
from .models import HostelPaymentSystem, Hostel

admin.site.register(Hostel)

admin.site.register(HostelPaymentSystem)

# Register your models here.
